#include <stdio.h>
#include <stdlib.h>
#include "linear-singly-linked-list.h"
#include "util.h"

int main(int argc, char const *argv[])
{
	printf("%d", getTaskCode());
	return 0;
}