function display() {
    document.querySelector("p").innerText += "Sahil";
}