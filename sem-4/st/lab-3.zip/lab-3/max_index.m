function index = max_index(a)
  [_, index] = max(a);
end
