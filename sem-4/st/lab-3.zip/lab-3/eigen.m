function [value, vector] = eigen(matrix)
  [value, vector] = eig(matrix)
end
