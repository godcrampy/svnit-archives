clc;
clear all;
x = input("Enter a Number: ");

if x > 0
  puts("Positive\n");
elseif x < 0
  puts("Negative\n");
else
  puts("zero\n");
end
 