clc;
clear all;

x = input("Enter number: ");
factorial(x)