clc;
clear all;
i = 1;
while i <= 10
  printf("5 x %d = %d\n", i, 5 * i);
  ++i;
end;
puts("\n\n");

for i = 1:10  
  printf("5 x %d = %d\n", i, 5 * i);
end;
