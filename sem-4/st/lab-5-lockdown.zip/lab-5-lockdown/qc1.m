pkg load symbolic;
clc;
clear all;

syms x y;
factor(x^2 - y^2)
