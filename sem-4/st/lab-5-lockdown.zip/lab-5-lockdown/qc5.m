pkg load symbolic;
clc;
clear all;

syms x y;
factor(x^5 - y^5)
