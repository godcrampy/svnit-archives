% Setup for symbolic package
pkg install -forge symbolic
pkg load symbolic

% Run the following in terminal
% $ pip install --user sympy
% $ pip install --user mpmath
