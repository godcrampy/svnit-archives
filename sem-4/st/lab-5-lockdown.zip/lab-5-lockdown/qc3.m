pkg load symbolic;
clc;
clear all;

syms x y;
factor((x^4 - 16) / (x^2 - 4))
