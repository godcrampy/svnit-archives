function stack = push(stack, n)
  stack = [stack n];
end
