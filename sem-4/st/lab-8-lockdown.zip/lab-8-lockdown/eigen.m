function s = eigen(sqr_matrix)
    s = sum(eig(sqr_matrix));
end
