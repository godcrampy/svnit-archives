function result = pass(vector)
  result = vector >= 30;
end
