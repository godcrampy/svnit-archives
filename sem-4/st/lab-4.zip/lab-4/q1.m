clc;
clear all;

y = rand(1, 100)
x = [1:100]

plot(x, y);