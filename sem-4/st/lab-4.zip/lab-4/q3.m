clc;
clear all;

x = 0:0.1:5*pi;
p = x.^2;

polar(x, p);