create table emp (
  id int primary key,
  name varchar(20),
  dept_no int,
  salary float
);

insert into emp values(101, 'Mark', 10, 5000.00);
insert into emp values(102, 'Dug', 10, 5500.00);
insert into emp values(103, 'Alan', 20, 6000.00);
insert into emp values(104, 'Peter', 30, 6200.00);
