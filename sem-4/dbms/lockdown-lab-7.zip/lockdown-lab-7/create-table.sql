create table students (
  id number primary key,
  name varchar(50),
  age number,
  stream varchar(20),
  marks number
);