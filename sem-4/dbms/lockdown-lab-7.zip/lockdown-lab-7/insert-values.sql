insert into students values(1, 'Arun', 21, 'BSc', 55);
insert into students values(2, 'Nisarg', 22, 'BTech', 65);
insert into students values(3, 'Aarav', 24, 'Mtech', 70);
insert into students values(4, 'Dhariya', 27, 'PhD', 75);
insert into students values(5, 'Dhruv', 23, 'MCA', 65);
insert into students values(6, 'Niraj', 22, 'MCom', 74);
insert into students values(7, 'Kevin', 24, 'MCA', 78);