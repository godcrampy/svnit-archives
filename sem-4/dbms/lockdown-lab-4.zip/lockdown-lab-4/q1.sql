declare
  message varchar2(20) := 'Hello World!';
begin
  dbms_output.put_line(message);
end;
/